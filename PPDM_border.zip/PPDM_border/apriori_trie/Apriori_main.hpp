
#include "Apriori.hpp"

extern Apriori * p_apriori;

int Apriori_main(char basket_filename[128], char outcomefile[128], double min_supp, double min_conf, 
				 unsigned long size_threshold  );